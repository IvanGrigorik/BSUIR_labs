/* --COPYRIGHT--,BSD
 * Copyright (c) 2016, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
/*
 *  structure.c
 *
 *  Summary
 *     MSP430G2955 board and Capacitive Touch Booster Pack
 *
 *  Details
 *     Capacitive Touch Booster Pack: 4 element wheel, middle button, and 
 *     proximity sensor.  MSP430 harware configuration is fRO_PINOSC_TA1_TB0.
 *
 */
#include "structure.h"

//PinOsc Volume down P2.1
const struct Element volume_down = {

              .inputPxselRegister = (uint8_t *)&P2SEL,  
              .inputPxsel2Register = (uint8_t *)&P2SEL2,  
              .inputBits = BIT1,
              // measured for a 1Mhz SMCLK
              .maxResponse = 121+655, // actual measure was 980
              .threshold = 121
};      

//PinOsc forward right P2.0
const struct Element right = {

              .inputPxselRegister = (uint8_t *)&P2SEL,  
              .inputPxsel2Register = (uint8_t *)&P2SEL2,  
              .inputBits = BIT0,
              // 1Mhz SMCLK
              .maxResponse = 113+655,
              .threshold = 113
};

//PinOsc Volume up, P1.4
const struct Element volume_up = {

              .inputPxselRegister = (uint8_t *)&P1SEL,
              .inputPxsel2Register = (uint8_t *)&P1SEL2,
              .inputBits = BIT4,
              // 1Mhz SMCLK
              .maxResponse = 118+655,
              .threshold = 118
};      

//PinOsc reverse left P2.2
const struct Element left = {

              .inputPxselRegister = (uint8_t *)&P2SEL,  
              .inputPxsel2Register = (uint8_t *)&P2SEL2,  
              .inputBits = BIT2,
              // 1Mhz SMCLK
              .maxResponse = 111+655,
              .threshold = 111
};      

//PinOsc Wheel: middle button P1.5
const struct Element middle_element = {

              .inputPxselRegister = (uint8_t *)&P1SEL,
              .inputPxsel2Register = (uint8_t *)&P1SEL2,
              .inputBits = BIT5,
              // When using an abstracted function to measure the element
              // the 100*(maxResponse - threshold) < 0xFFFF
              // ie maxResponse - threshold < 655
              .maxResponse = 350+655,
              .threshold = 350
}; 

//PinOsc proximity: P2.3
const struct Element proximity_element = {

              .inputPxselRegister = (uint8_t *)&P2SEL,  
              .inputPxsel2Register = (uint8_t *)&P2SEL2,  
              .inputBits = BIT3,
              .maxResponse = 200,
              .threshold = 130
};

//*** CAP TOUCH HANDLER *******************************************************/
// This defines the grouping of sensors, the method to measure change in
// capacitance, and the function of the group

const struct Sensor wheel =
               { 
            	  .halDefinition = fRO_PINOSC_TA1_TB0,
                  .numElements = 4,
                  .points = 64,
                  .sensorThreshold = 75,
                  .baseOffset = 0,
                  // Pointer to elements
                  .arrayPtr[0] = &volume_up,  // point to first element
                  .arrayPtr[1] = &right,  
                  .arrayPtr[2] = &volume_down,  
                  .arrayPtr[3] = &left,  
                  // Timer Information
                  .measGateSource= TIMER_SMCLK,
                  .sourceScale= TIMER_SOURCE_DIV_0,
                  .accumulationCycles= 3200     
                  //.accumulationCycles = 32                                          
               };

const struct Sensor middle_button =
               { 
            	  .halDefinition = fRO_PINOSC_TA1_TB0,
                  .numElements = 1,
                  .baseOffset = 4,
                  // Pointer to elements
                  .arrayPtr[0] = &middle_element,  // point to first element
                  // Timer Information
                  .measGateSource= TIMER_SMCLK,
                  .sourceScale= TIMER_SOURCE_DIV_0,
                  .accumulationCycles= 3200     
               };

const struct Sensor proximity_sensor =
               { 
            	  .halDefinition = fRO_PINOSC_TA1_TB0,
                  .numElements = 1,
                  .baseOffset = 5,
                  // Pointer to elements
                  .arrayPtr[0] = &proximity_element,  // point to first element
                  // Timer Information
                  .measGateSource= TIMER_SMCLK,
                  .accumulationCycles= 1600              
               };



