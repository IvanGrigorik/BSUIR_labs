var searchData=
[
  ['basecnt',['baseCnt',['../group___g_l_o_b_a_l___v_a_r_s.html#ga6dc372c927ccb74812fbef3e0a6adac5',1,'CTS_Layer.c']]]
];
