var searchData=
[
  ['capacitive_20touch_20implementations',['Capacitive Touch Implementations',['../group___c_t_s___h_a_l.html',1,'']]]
];
