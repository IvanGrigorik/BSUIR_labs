var searchData=
[
  ['ctsstatusreg',['ctsStatusReg',['../group___g_l_o_b_a_l___v_a_r_s.html#ga48dbba7373b0d392f977a67bc9e92f6b',1,'CTS_Layer.c']]]
];
