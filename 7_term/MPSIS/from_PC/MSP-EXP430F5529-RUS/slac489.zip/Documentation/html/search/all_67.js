var searchData=
[
  ['global_20variables',['Global Variables',['../group___g_l_o_b_a_l___v_a_r_s.html',1,'']]]
];
