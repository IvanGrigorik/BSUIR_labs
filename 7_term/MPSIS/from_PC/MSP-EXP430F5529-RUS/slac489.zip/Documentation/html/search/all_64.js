var searchData=
[
  ['dominant_5felement',['Dominant_Element',['../group___c_t_s__support.html#ga78b1beaf1442cbfb831990ae521fe56e',1,'Dominant_Element(const struct Sensor *groupOfElements, uint16_t *deltaCnt):&#160;CTS_Layer.c'],['../group___c_t_s__support.html#ga78b1beaf1442cbfb831990ae521fe56e',1,'Dominant_Element(const struct Sensor *, uint16_t *):&#160;CTS_Layer.c']]]
];
